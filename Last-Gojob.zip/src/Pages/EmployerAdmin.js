import React from "react";

const EmployerAdmin = () => {
    return (
        <>
            <div>EmployerAdmin</div>
        </>
    );
};

export default EmployerAdmin;
