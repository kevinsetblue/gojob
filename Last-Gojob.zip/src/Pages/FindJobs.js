import React from "react";
import Findjobform from "../Components/Findjobform";

const FindJobs = () => {
    return (
        <>
            <Findjobform />
        </>
    );
};

export default FindJobs;
