import React from "react";

const RecentJobTab = () => {
    return <div>RecentJobTab</div>;
};

export default RecentJobTab;
